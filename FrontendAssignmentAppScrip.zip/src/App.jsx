import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import './index.css';
import F12Main from './F12Main';

import Frame48098219 from './pages/Frame48098219';
import PhonePlp from './pages/PhonePlp';
import WebPlpHiddenFilter from './pages/WebPlpHiddenFilter';
import WebPlpWithFilter from './pages/WebPlpWithFilter';
import WebPlpWithFilterExpanded from './pages/WebPlpWithFilterExpanded';


const router = createBrowserRouter([
  { path: '/', element: <F12Main /> },
{ path: '/Frame48098219', element: <Frame48098219 /> },
{ path: '/PhonePlp', element: <PhonePlp /> },
{ path: '/WebPlpHiddenFilter', element: <WebPlpHiddenFilter /> },
{ path: '/WebPlpWithFilter', element: <WebPlpWithFilter /> },
{ path: '/WebPlpWithFilterExpanded', element: <WebPlpWithFilterExpanded /> },
]);

export default function App() {
  return (
    <RouterProvider router={router} />
  );
}