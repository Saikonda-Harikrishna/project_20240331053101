import './Frame48098219.css'

export default function Frame48098219() {
  return (
    <div className="frame-48098219">
    </div>
  )
}